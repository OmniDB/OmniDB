rm -f *.o *.so
